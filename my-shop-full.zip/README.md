# My Demo Shop

Simple e-commerce starter with Node.js, SQLite and Stripe.